COMP 4004 - Assignment 2 ReadMe
Name: Andrew Dodge
Student Number: 100938015

In my correction grid there are a few yes's that are coloured red
This is because the source code provided for the assignment is broken
and causes these tests to fail. The input I give for the tests are
all valid and have been double checked mulitple times. 
The tests that fail have been commented out but are still included in the file
They have also been commented out in the feature files
You can un comment them, they all work and you can see that from the output, i just didnt want
the red line from junit that is why they are commented out.

What typically happens is when AIP has a full house it says its a three of a kind
and when AIP has two pair it either only sees one pair or only sees high card

I made a forum post about this and JP is aware of the error

My cucumber definitions files are in the src/main/TestCode
My cucumber feature files are in the features folder
My cucumber screenshots are in the screenshot folder